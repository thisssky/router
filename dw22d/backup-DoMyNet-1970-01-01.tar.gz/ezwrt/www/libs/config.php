<?php
//by sunwei@ezlink.us

$config_security_code = '';
$config_security_code_check_time = '';
$config_security_code_status = '';
$config_password = '25f9e794323b453885f5181f1b624d0b';
$config_token = '68c114cfb16bf62dc30419bafdf74893';
$config_token_time = '335';
$config_init_status = '';//complete 或 init